# Quake JS - JavaScript porting

![alt screenshot](https://raw.githubusercontent.com/lrusso/Quake1/master/Quake1.png)

## Web:

https://lrusso.github.io/Quake1/Quake1.htm

## Based on the work of:

https://github.com/Triang3l/WebQuake **(Commit April 21, 2019)**
